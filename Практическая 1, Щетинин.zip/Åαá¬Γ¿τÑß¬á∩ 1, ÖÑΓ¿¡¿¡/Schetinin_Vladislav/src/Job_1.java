public class Job_1 {
    public static void main(String[] args) {
        // Объявление переменных разных типов данных
        int a = 10;
        double b = 5.5;
        boolean flag = true;
        char letter = 'A';

        // Арифметические операции
        int sum = a + 5;
        double product = b * 2;

        // Логические операции
        boolean result = flag && (a > 5);

        // Вывод результатов на консоль
        System.out.println("Sum: " + sum);
        System.out.println("Product: " + product);
        System.out.println("Logical result: " + result);
        System.out.println("Character: " + letter);
    }
}

